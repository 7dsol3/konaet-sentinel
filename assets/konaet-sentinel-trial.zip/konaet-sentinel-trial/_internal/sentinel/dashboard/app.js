"use strict";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const ui = {
  data: null,
  selected: null,
  lastHistory: [],
  painting: false,
};

const STATE_LABEL = { ok: "Limpo", watch: "Vigilância", alert: "Alerta", quarantine: "Quarentena", banned: "Banido" };

function machineShort(value) {
  const text = String(value || "");
  if (!text) return "—";
  return text.length > 16 ? `${text.slice(0, 12)}…${text.slice(-4)}` : text;
}

function whenText(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[ch]));
}

function pct(value) {
  return `${Math.round(Number(value || 0) * 100)}%`;
}

function num(value) {
  return Number(value || 0).toLocaleString("pt-BR");
}

function clockText(seconds) {
  const s = Math.max(0, Math.floor(Number(seconds || 0)));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

function initials(name) {
  const parts = String(name || "?").trim().split(/\s+/);
  const raw = parts.length > 1 ? parts[0][0] + parts[1][0] : parts[0].slice(0, 2);
  return raw.toUpperCase();
}

function stateChip(level, text) {
  return `<span class="chip" data-state="${esc(level)}">${esc(text || STATE_LABEL[level] || level)}</span>`;
}

/* ------------------------------------------------------------------ render */
function render(data) {
  ui.data = data;
  const counts = data.counts || {};
  $("#server-name").textContent = data.server
    ? `${data.server} · ${data.mode === "live" ? "produção" : "demonstração"}`
    : "Servidor local";
  const mode = $("#mode-pill");
  mode.textContent = data.demo ? "DEMO" : "AO VIVO";
  mode.className = `pill ${data.demo ? "demo" : "live"}`;
  const profile = data.profile || (data.players && data.players[0] && data.players[0].profile) || {};
  const profilePill = $("#profile-pill");
  profilePill.textContent = profile.label || "perfil —";
  profilePill.title = profile.ml_calibrated
    ? "IA comportamental calibrada para este perfil"
    : "Regras ativas; IA aguarda calibração com telemetria rotulada";
  const model = data.model || null;
  const calibrated = Boolean(model && profile.ml_calibrated);
  $("#ai-state").textContent = calibrated ? "Calibrada" : "Regras ativas";
  $("#ai-detail").textContent = model
    ? `${(model.features || []).length} features · janela de 30 s${calibrated ? "" : " · IA aguarda calibração"}`
    : "modelo ausente · somente regras";
  $("#ai-meter").style.width = calibrated ? "88%" : "34%";

  $("#kpi-online").textContent = num(counts.online);
  $("#kpi-players").textContent = `${num(counts.players)} sessões`;
  $("#kpi-watch").textContent = num(counts.watch);
  $("#kpi-alert").textContent = num(counts.alert);
  $("#kpi-alerts-total").textContent = `${num(data.alerts)} no total`;
  $("#kpi-quarantine").textContent = num(counts.quarantine);
  $("#kpi-shield").textContent = `${num((data.shield || {}).actions)} ações do escudo`;
  $("#kpi-banned").textContent = num(counts.banned);

  renderAccess(data.access || null);
  renderPlayers(data.players || []);
  renderFeed(data.recent_alerts || []);
  renderShield(data.shield || {});
  renderBench(data.benchmark || {});
  renderBans(data.bans || {});
  renderNetwork(data.network || {});

  $("#foot-model").textContent = `modelo ${data.model ? data.model.sha256.slice(0, 12) : "regras"}`;
  $("#foot-events").textContent = `${num(data.events)} eventos`;
  const ledger = data.ledger || {};
  $("#foot-ledger").textContent = ledger.head
    ? `ledger #${num(ledger.seq)} · ${String(ledger.head).slice(0, 10)}`
    : "ledger —";
}

function renderAccess(access) {
  const card = $("#access-card");
  const label = $("#access-label");
  const title = $("#access-title");
  const detail = $("#access-detail");
  const link = $("#access-link");
  const store = "https://7dsol3.github.io/konaet-sentinel/";
  if (!access) {
    label.textContent = "Acesso";
    title.textContent = "Local";
    detail.textContent = "sem licença carregada";
    link.href = store;
    return;
  }
  if (access.trial) {
    label.textContent = "Teste grátis";
    title.textContent = `${Number(access.days_left || 0).toFixed(1)} dias`;
    detail.textContent = "de 30 dias · 1 servidor";
    link.textContent = "Comprar licença";
    card.dataset.kind = "trial";
  } else {
    label.textContent = "Licença";
    title.textContent = String(access.plan || "").toUpperCase();
    detail.textContent = `${Number(access.days_left || 0).toFixed(1)} dias · ${access.license_id || ""}`;
    link.textContent = "Renovar";
    card.dataset.kind = "license";
  }
  link.href = store;
}

function renderPlayers(players) {
  const body = $("#players-body");
  $("#players-count").textContent = `${players.length} sessões`;
  if (!players.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty">aguardando telemetria…</td></tr>';
    renderDetail(null);
    return;
  }
  if (!ui.selected || !players.some((p) => p.id === ui.selected)) {
    const preset = new URLSearchParams(location.search).get("player");
    ui.selected = preset && players.some((p) => p.id === preset) ? preset : players[0].id;
  }
  body.innerHTML = players.map((player) => {
    const top = (player.evidence || [])[0] || {};
    const risk = Math.max(0, Math.min(1, Number(player.risk || 0)));
    return `
      <tr data-id="${esc(player.id)}" class="${player.id === ui.selected ? "selected" : ""}">
        <td>
          <div class="player-cell">
            <span class="avatar">${esc(initials(player.name))}</span>
            <span class="player-name"><strong>${esc(player.name)}</strong><small>${esc(player.id)}</small></span>
          </div>
        </td>
        <td>${stateChip(player.state)}</td>
        <td class="num" data-level="${esc(player.state)}">
          <div class="riskbar"><span class="track"><i class="fill" style="width:${risk * 100}%"></i></span><b>${pct(risk)}</b></div>
        </td>
        <td class="hide-sm"><span class="evidence-mini" title="${esc(top.title || "")}">${esc(top.title || "—")}</span></td>
        <td class="num hide-md mono">${esc(Math.round(player.ping_ms || 0))} ms</td>
      </tr>`;
  }).join("");
  const current = players.find((p) => p.id === ui.selected) || players[0];
  renderDetail(current);
}

function renderDetail(player) {
  const name = $("#detail-name");
  const chip = $("#detail-state");
  if (!player) {
    name.textContent = "Detalhe do jogador";
    chip.textContent = "—";
    chip.removeAttribute("data-state");
    $("#detail-meta").textContent = "Selecione uma linha da tabela.";
    $("#evidence-list").innerHTML = '<p class="empty">Sem evidências para este jogador.</p>';
    $("#features").innerHTML = "";
    ui.lastHistory = [];
    drawChart([]);
    return;
  }
  name.textContent = player.name;
  chip.textContent = STATE_LABEL[player.state] || player.state;
  chip.dataset.state = player.state;
  const pos = player.pos ? `${player.pos[0]}, ${player.pos[1]}` : "—";
  const profile = player.profile || {};
  const rows = [
    `<span>id <b>${esc(player.id)}</b></span>`,
    `<span>pos <b>${esc(pos)}</b></span>`,
    `<span>ping <b>${esc(Math.round(player.ping_ms || 0))} ms</b></span>`,
    `<span>sessão <b>${clockText(player.session_s)}</b></span>`,
    `<span>alertas <b>${num(player.alert_count)}</b></span>`,
    `<span>perfil <b>${esc(profile.label || "—")}</b></span>`,
  ];
  if (player.machine) {
    rows.push(`<span>máquina <b title="${esc(player.machine)}">${esc(machineShort(player.machine))}</b></span>`);
  }
  $("#detail-meta").innerHTML = rows.join("");

  const evidence = (player.evidence || []).slice(-6).reverse();
  $("#evidence-list").innerHTML = evidence.length
    ? evidence.map((item) => {
        const sev = Number(item.severity || 0);
        const cls = sev >= 0.8 ? "high" : sev >= 0.5 ? "mid" : "low";
        return `<div class="evidence-item" data-sev="${cls}">
          <strong>${esc(item.title)} · ${pct(sev)}</strong>
          <span>${esc(item.detail)}</span>
        </div>`;
      }).join("")
    : '<p class="empty">Sem evidências para este jogador.</p>';

  const contributions = (player.contributions || []).slice(0, 3);
  const maxAbs = Math.max(1e-9, ...contributions.map((c) => Math.abs(Number(c.contribution || 0))));
  $("#features").innerHTML = contributions.length
    ? contributions.map((c) => `
        <div class="feature">
          <span>${esc((player.feature_labels || {})[c.feature] || c.feature)}</span>
          <b>${Number(c.value).toFixed(2)}</b>
          <span class="bar"><i style="width:${Math.abs(c.contribution) / maxAbs * 100}%"></i></span>
        </div>`).join("")
    : "";

  ui.lastHistory = player.risk_history || [];
  drawChart(ui.lastHistory);
}

function renderFeed(alerts) {
  const feed = $("#feed");
  $("#feed-count").textContent = `${alerts.length} eventos`;
  if (!alerts.length) {
    feed.innerHTML = '<li class="empty">Nenhum alerta ainda.</li>';
    return;
  }
  feed.innerHTML = alerts.slice(0, 10).map((alert) => `
    <li data-level="${esc(alert.state)}">
      <div class="feed-top">
        <strong>${esc(alert.name)} <span class="feed-code">${esc(alert.code)}</span></strong>
        <time>${clockText(alert.t)}</time>
      </div>
      <p>${esc(alert.warden)}</p>
    </li>`).join("");
}

function renderBans(bans) {
  const last = bans.last || null;
  $("#ban-name").textContent = last ? last.name : "Nenhum banimento ativo";
  $("#ban-reason").textContent = last
    ? last.reason
    : "O Sentinela sinaliza e prova; a decisão de banir continua humana.";
  $("#ban-why").textContent = last ? last.why || "" : "";
  $("#ban-machine").textContent = last ? machineShort(last.machine) : "—";
  $("#ban-machine").title = last ? String(last.machine || "") : "";
  $("#ban-operator").textContent = last ? last.operator || "—" : "—";
  $("#ban-when").textContent = last ? whenText(last.ts_utc) : "—";
  $("#ban-case").textContent = last ? last.id || "—" : "—";
  $("#ban-demo").hidden = !(last && last.demo);
}

function renderNetwork(net) {
  const state = $("#net-state");
  const enabled = net.enabled !== false;
  const supported = net.supported !== false;
  const counts = net.counts || {};
  $("#net-total").textContent = num(counts.total);
  $("#net-established").textContent = num(counts.established);
  $("#net-listening").textContent = num(counts.listening);
  $("#net-exposed").textContent = num(counts.exposed);
  $("#net-public").textContent = num(counts.public_established);
  $("#net-processes-count").textContent = num(counts.processes);

  if (!enabled) {
    state.textContent = "DESLIGADO";
    state.dataset.state = "watch";
  } else if (!supported) {
    state.textContent = "SEM SUPORTE";
    state.dataset.state = "watch";
  } else if (net.state === "error") {
    state.textContent = "ERRO";
    state.dataset.state = "fail";
  } else if (net.state === "starting") {
    state.textContent = "AMOSTRANDO";
    state.dataset.state = "watch";
  } else {
    state.textContent = "LEITURA";
    state.dataset.state = "ok";
  }

  const observations = net.observations || [];
  $("#net-observations").innerHTML = observations.length
    ? observations.slice(0, 6).map((item) => `
        <li data-kind="${esc(item.kind || "review")}">
          <strong>${esc(item.title)}<em>${pct(item.severity)}</em></strong>
          <span>${esc(item.detail)}</span>
        </li>`).join("")
    : `<li class="net-empty">${esc(net.state === "starting" ? "Aguardando a primeira amostra." : "Nenhuma observação nesta amostra. Ausência não prova que a máquina está limpa.")}</li>`;

  const processes = net.processes || [];
  $("#net-processes").innerHTML = processes.length
    ? processes.slice(0, 6).map((row) => `
        <li title="PIDs: ${esc((row.pids || []).join(", ") || "—")}"><span>${esc(row.name)}</span><b>${num(row.established)}/${num(row.listening)}</b></li>`).join("")
    : '<li class="net-empty">Sem processos com conexão.</li>';

  const listeners = net.listeners || [];
  $("#net-listeners").innerHTML = listeners.length
    ? listeners.slice(0, 6).map((row) => `
        <li data-known="${row.known ? "true" : "false"}">
          <span>${esc(row.process)}</span><code>${esc(row.address)}:${esc(row.port)}</code>
        </li>`).join("")
    : '<li class="net-empty">Nenhuma porta exposta conhecida.</li>';

  const pieces = ["Somente leitura: não bloqueia, não encerra e não envia dados para fora."];
  if (net.error) pieces.push(`Erro da amostra: ${net.error}.`);
  if (net.note) pieces.push(net.note);
  pieces.push("Não substitui firewall, EDR ou IDS.");
  $("#net-note").textContent = pieces.join(" ");
}

function renderShield(shield) {  const list = $("#shield-list");
  const records = shield.last || [];
  $("#shield-count").textContent = `${num(shield.actions)} ações`;
  if (!records.length) {
    list.innerHTML = '<li class="empty">Nenhuma ação necessária.</li>';
    return;
  }
  list.innerHTML = records.slice(-6).reverse().map((record) => `
    <li>
      <strong>${esc(record.name)} · ${esc(record.title)}</strong>
      <span>${esc(record.reason)}</span>
      <code>${esc((record.actions || []).join(" · "))}</code>
    </li>`).join("");
}

function renderBench(bench) {
  const list = $("#bench-list");
  const state = $("#bench-state");
  if (!bench.available) {
    state.textContent = "AUSENTE";
    state.dataset.state = "fail";
    list.innerHTML = '<li><span>Rode <code>python -m sentinel.cli train</code></span></li>';
    return;
  }
  state.textContent = bench.pass ? "PASS" : "FAIL";
  state.dataset.state = bench.pass ? "pass" : "fail";
  const gates = (bench.gates || []).slice(0, 5);
  const labels = {
    rules_overt_recall: "Recall · regras (overt)",
    hybrid_stealth_recall: "Recall · stealth",
    hybrid_legit_fpr: "Falso positivo",
    window_auc: "AUC por janela",
    overall_hybrid_recall: "Recall geral",
  };
  list.innerHTML = gates.map((gate) => `
    <li><span>${esc(labels[gate.gate] || gate.gate)}</span><b>${Number(gate.value).toFixed(3)}</b></li>`).join("");
  $("#bench-note").textContent = bench.dataset && bench.dataset.disclaimer
    ? "Sintético; não prova produção."
    : "Dataset sintético; não prova produção.";
}

/* ------------------------------------------------------------------ chart */
function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function drawChart(history) {
  const canvas = $("#risk-chart");
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 420;
  const height = canvas.clientHeight || 156;
  canvas.width = Math.round(width * dpr);
  canvas.height = Math.round(height * dpr);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const pad = { top: 12, right: 6, bottom: 10, left: 26 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const y = (value) => pad.top + (1 - Math.max(0, Math.min(1, value))) * plotH;

  ctx.strokeStyle = "rgba(46, 41, 33, .12)";
  ctx.lineWidth = 1;
  ctx.font = "9px Consolas, monospace";
  ctx.fillStyle = "#8d8576";
  [0, 0.25, 0.5, 0.75, 1].forEach((tick) => {
    const yy = y(tick);
    ctx.beginPath();
    ctx.moveTo(pad.left, yy);
    ctx.lineTo(width - pad.right, yy);
    ctx.stroke();
    ctx.fillText(String(Math.round(tick * 100)), 2, yy + 3);
  });

  if (!history || history.length < 2) {
    ctx.fillStyle = "#8d8576";
    ctx.font = "11px Segoe UI, sans-serif";
    ctx.fillText("aguardando janelas de 30 s…", pad.left + 8, pad.top + plotH / 2);
    return;
  }

  const xs = (index) => pad.left + (index / (history.length - 1)) * plotW;
  const series = [
    { key: "risk", color: cssVar("--clay") || "#b05f43", width: 2, fill: true },
    { key: "rule", color: cssVar("--plum") || "#77627f", width: 1.2, dash: [3, 3] },
    { key: "ml", color: cssVar("--sage") || "#5f7c62", width: 1.2, dash: [1, 3] },
  ];

  for (const item of series) {
    ctx.beginPath();
    history.forEach((point, index) => {
      const px = xs(index);
      const py = y(Number(point[item.key] || 0));
      if (index === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.strokeStyle = item.color;
    ctx.lineWidth = item.width;
    ctx.setLineDash(item.dash || []);
    ctx.stroke();
    ctx.setLineDash([]);
    if (item.fill) {
      ctx.lineTo(xs(history.length - 1), pad.top + plotH);
      ctx.lineTo(pad.left, pad.top + plotH);
      ctx.closePath();
      ctx.fillStyle = "rgba(176, 95, 67, .09)";
      ctx.fill();
    }
  }
}

/* ------------------------------------------------------------------ boot */
async function poll() {
  if (ui.painting) return;
  ui.painting = true;
  try {
    const response = await fetch("/api/state", { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    render(await response.json());
  } catch (error) {
    $("#server-name").textContent = "Sem conexão com o serviço local";
    $("#mode-pill").textContent = "OFFLINE";
    $("#mode-pill").className = "pill";
  } finally {
    ui.painting = false;
  }
}

$("#players-body").addEventListener("click", (event) => {
  const row = event.target.closest("tr[data-id]");
  if (!row) return;
  ui.selected = row.dataset.id;
  $$("#players-body tr").forEach((item) => item.classList.toggle("selected", item === row));
  const player = (ui.data?.players || []).find((item) => item.id === ui.selected);
  if (player) renderDetail(player);
});

window.addEventListener("resize", () => drawChart(ui.lastHistory));
setInterval(() => {
  $("#clock").textContent = new Date().toLocaleTimeString("pt-BR", { hour12: false });
}, 1000);
$("#clock").textContent = new Date().toLocaleTimeString("pt-BR", { hour12: false });

poll();
setInterval(poll, 1500);
