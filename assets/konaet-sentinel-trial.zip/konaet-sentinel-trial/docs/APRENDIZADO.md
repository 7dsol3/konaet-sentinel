# Aprendizado local sob confirmação humana

A partir da versão 1.3, o Konaet Sentinel consegue **lembrar de um caso
confirmado por uma pessoa** e usar essa memória no motor em execução. O objetivo
é fechar o intervalo entre “o operador viu a trapaça” e “o motor reconhece
aquele comportamento”: no teste reproduzível incluído, a promoção levou menos de
um segundo e a memória passou a valer na janela seguinte, sem reiniciar o
serviço.

Esta página existe para separar o que foi medido do que seria uma promessa
fácil. **O Sentinel não aprende sozinho com tráfego não rotulado** e não promete
detectar variantes que ninguém confirmou.

## O fluxo, em cinco passos

1. O operador seleciona um jogador no dashboard e clica em **Confirmar
   trapaça** ou **Confirmar limpo**. Isso é uma decisão humana explícita; um
   alerta do motor, sozinho, não vira caso.
2. O serviço congela até 12 janelas de 30 segundos daquela sessão — os mesmos
   sinais que o motor já calculou — e grava um registro `case` no journal
   local `var/adaptation/cases.jsonl`, com encadeamento SHA-256.
3. Para um caso de trapaça, o construtor mede a dispersão interna das janelas,
   a separação em relação às âncoras legítimas sintéticas e monta protótipos no
   espaço dos 17 sinais. Casos antigos que já não se separam são deixados de
   fora, para que um caso ruim não bloqueie todo o aprendizado futuro.
4. A memória candidata passa por gates. Se passar, é gravada em
   `var/adaptation/memory.json`, o motor troca a memória ativa e o dashboard
   mostra a nova pontuação. Se não passar, o caso fica registrado, mas a memória
   anterior continua valendo.
5. O operador pode **reverter** a memória no painel. O modelo-base, as regras e
   o escudo continuam funcionando; o journal preserva os casos para auditoria.

Um caso **limpo** não vira protótipo de trapaça: ele é gravado como negativo e
usado para testar se a memória acende nele. Se acender, o ajuste é recusado.

## O que a memória muda — e o que não muda

- O modelo logístico base **não é retreinado** e seus pesos não mudam.
- A memória é um sinal adicional de similaridade, comparado com as âncoras
  legítimas; ela entra no risco como `max(regra, IA, memória)`.
- A memória não cria banimento. O estado máximo continua dependendo da política
  humana; não existe auto-ban.
- O escudo continua sendo o mesmo: comandos de mitigação para o adaptador do
  servidor, não expulsão automática.
- A memória é local. Nenhuma janela, nome ou hash de máquina é enviado para a
  Konaet.

## Gates de promoção

O construtor recusa a memória se qualquer condição abaixo falhar:

| Gate | Critério |
|---|---|
| Janelas do caso | pelo menos 2 janelas válidas de 30 s |
| Dispersão interna | RMS em z-score entre janelas ≤ 5,0 |
| Separação | mediana da razão “distância ao legítimo / distância interna” ≥ 1,5 |
| Falso positivo nas âncoras | ≤ 2% das janelas legítimas com score ≥ 0,68 |
| Pior legítimo | nenhuma janela legítima das âncoras com score ≥ 0,68 |
| Leave-one-out | o caso precisa se reconhecer sem a própria janela: máximo ≥ 0,68 e mediana ≥ 0,55 |
| Casos limpos | nenhum caso confirmado como limpo pode acender a memória |
| Caso recém-confirmado | o caso que motivou o ajuste precisa entrar; os antigos podem ser ignorados |

Limites operacionais: até 48 entradas ativas e até 200 casos no histórico. A
memória carrega no máximo 12 protótipos por caso.

## Prova reproduzível

`artifacts/adaptation.json` é gerado por:

```bash
python tools/adaptation_proof.py
```

O relatório usa um caso sintético determinístico de velocidade stealth, com
semente própria, e as âncoras sintéticas do produto. Resultado da build 1.3.0
nesta máquina:

| Medida | Resultado |
|---|---|
| Caso confirmado | 11 janelas; pico `alert` |
| Promoção | aceita; 1 entrada de memória |
| Latência de montagem + gravação | mediana 211 ms (3 execuções) |
| FPR nas âncoras | 0,000 (160 janelas legítimas) |
| Pior score legítimo nas âncoras | 0,000 |
| Recall nas janelas do caso confirmado | 1,000 (11/11) |
| Estilo semelhante em 3 sementes não usadas no caso | 1,000 em cada |
| Estilo diferente (autoclick) fora de distribuição | 0,000 |

A última linha é o limite, não um defeito escondido: a memória lembra do padrão
confirmado e não é um detector universal. Os números de falso positivo usam as
âncoras sintéticas do simulador; **não** provam o seu servidor. A latência é
desta máquina de build e não é SLA.

O relatório também guarda o SHA-256 do modelo, das âncoras e da memória. O hash
da memória muda quando o conteúdo muda; ele detecta alteração acidental, mas
**não é assinatura digital** contra alguém que tenha escrita no disco e recalcule
o hash. O journal e o ledger encadeados servem para detectar edição casual e
para reconstruir a ordem dos fatos, não para provar honestidade do operador.

## Integridade e falha segura

- Journal adulterado: o serviço não carrega a memória e o comando `audit` falha
  na verificação `aprendizado`.
- Memória com hash divergente, modelo-base diferente, âncoras diferentes,
  protótipo fora do caso ou estrutura inválida: a memória é rejeitada por
  inteiro; o motor segue com regras e modelo base.
- Reversão: move a memória para `var/adaptation/archive/` e desliga o sinal no
  motor; o journal continua íntegro.
- Modo demo usa `var/adaptation/demo/`, separado da memória de produção.

## API e auditoria

| Rota | Efeito |
|---|---|
| `GET /api/adaptation` | estado, casos, entradas, hashes, validação e erros |
| `POST /api/feedback` | confirma um caso; exige `X-Sentinel-Action: feedback` |
| `POST /api/adapt/rollback` | reverte a memória; exige `X-Sentinel-Action: rollback` |

Os POSTs também respeitam a origem e, quando o serviço escuta fora do loopback,
o token administrativo já usado pelo restante da API. O ledger registra
`feedback_case`, `memory_swapped` e `memory_rollback` com os hashes
correspondentes. O comando:

```bash
python -m sentinel audit
```

inclui a verificação `aprendizado`, que confere âncoras, journal e memória, além
do hash do executável no pacote congelado.

## Quando confirmar

- Confirme **trapaça** quando houver evidência que você consegue explicar:
  velocidade, alcance, cadência, mira ou padrão agregado, com a janela e o
  contexto.
- Confirme **limpo** quando o alerta foi um falso positivo claro. Isso ajuda a
  testar a memória contra o caso legítimo; não “perdoa” automaticamente outros
  alertas.
- Não confirme por impulso em um único alerta sem olhar a evidência. A memória
  é local, mas uma confirmação errada pode ensinar o padrão errado — os gates
  reduzem o risco, não eliminam o julgamento humano.

## Limites declarados

- Aprendizado **não autônomo**: sem confirmação humana, não há novo caso.
- Sem garantia sobre variantes futuras; a memória é tão boa quanto o caso
  confirmado e a separação medida.
- Sem prova de produção: os números são sintéticos e determinísticos.
- Sem assinatura digital da memória; hash e cadeia detectam edição, não um
  adversário com controle total do disco.
- Sem ban automático: a decisão continua humana, como no restante do produto.

Se você precisa de um detector para uma família nova de trapaça, o caminho é
telemetria rotulada + caso confirmado + validação no seu servidor. O produto
entrega o mecanismo e os gates; não vende a ilusão de que o primeiro caso cobre
todas as variantes.
