# Segurança e limites do Konaet Sentinel

Este documento diz o que a proteção faz, o que ela **não** faz e como verificar
cada afirmação. O produto não promete ser impossível de copiar; nenhum software
distribuído é. O que existe é uma combinação de controles verificáveis.

## 1. Modelo de ameaça

| Ameaça | Controle | Limite explícito |
|---|---|---|
| Jogador usa cheat e afeta os outros | regras + modelo + escudo no servidor | depende de telemetria autoritativa e do adaptador |
| Cliente adultera posição/velocidade | servidor calcula e envia a posição válida | se o servidor confiar no cliente, o motor não corrige isso |
| Operador edita a evidência | cadeia SHA-256 com `prev` e `hash` | truncar o fim não é detectável sem cópia externa |
| Cópia não autorizada do binário | build compilado, fonte privada, EULA, marca | engenharia reversa e cópia continuam possíveis |
| Chave de licença forjada | assinatura Ed25519; cliente só tem a pública | a chave privada do vendedor é o ponto único de confiança |
| Chave usada em outra máquina | vínculo opcional ao prefixo do machine id | prefixo é curto; é dissuasão, não identidade criptográfica |
| Conta nova na mesma máquina | hash salgado da instalação + ban manual | trocar componentes, reinstalar ou falsificar o ambiente muda o hash |
| Trial reiniciado | dois arquivos selados + detecção de relógio para trás | apagar os dois arquivos reinicia o teste |
| Relógio do sistema adiantado | trial usa o maior `seen` e o menor `started` | adiantar o relógio só encurta o próprio prazo |

O ativo mais valioso não é o binário: é o **modelo treinado, o código e a chave
privada**. Por isso o repositório de código é privado e `var/` nunca é publicado.

## 2. Licença Ed25519

Formato:

```
KSNT1.<payload_base64url>.<assinatura_base64url>
```

O payload canônico é JSON com `v, id, plan, iat, exp, seats, buyer, machine,
note`, serializado com chaves ordenadas e sem espaços. A assinatura cobre os
bytes exatos do payload. O cliente embute apenas a chave pública
(`sentinel/license.py` → `PUBLIC_KEY_HEX`).

Verificações feitas offline:

- assinatura Ed25519 válida;
- versão de licença suportada;
- `exp > iat`;
- vínculo de máquina, quando presente;
- expiração: licença vencida **não** cai para o trial; o produto bloqueia e
  mostra a data de renovação.

A implementação foi testada contra o vetor 1 do RFC 8032 em
`tests/test_license.py`. A chave privada de produção fica em
`var/keys/ed25519_private.key`, fora do git, e deve ter cópia em cofre seguro.
Perder a privada impede emitir novas chaves, mas não invalida as já emitidas.

## 3. Trial de 30 dias

O selo é `magic "KS1" | salt(16) | nonce(12) | ciphertext | HMAC-SHA256(32)`.
A chave deriva do machine id via PBKDF2-HMAC-SHA256 com 120 mil iterações e um
sal fixo do produto. O fluxo de cifra é SHA-256 em modo contador; a autenticação
é encrypt-then-MAC. Editar um byte invalida o selo e o produto pede suporte em
vez de conceder mais 30 dias.

Dois arquivos são gravados:

- Windows: `%LOCALAPPDATA%\KonaetSentinel\trial.bin` e
  `%APPDATA%\KonaetSentinel\trial.bin`;
- Linux: `$XDG_STATE_HOME/konaet-sentinel/trial.bin` e
  `$XDG_CONFIG_HOME/konaet-sentinel/trial.bin`.

**Limitação declarada:** apagar os dois arquivos reinicia o trial. Isso é
intencional e documentado; um trial offline não consegue distinguir “usuário
novo” de “usuário que apagou o estado” sem um servidor. O trial serve para
avaliação, não para cobrança. Quem precisa de prazo garantido usa licença paga.

Relógio para trás mais de um dia, ou anterior ao início, bloqueia com mensagem
de adulteração. Adiantar o relógio não aumenta o prazo: `seen` é monotônico.

## 4. Banimento manual por máquina

O registro fica em `var/bans.json` e guarda apenas o hash `ks1-…`, nunca o
identificador cru. O hash é calculado por `sentinel.machine.fingerprint()` no
processo confiável do operador e enviado no campo `machine` do `join`. Cada caso
tem id, jogador, nome, motivo, explicação, operador, data, validade opcional e
estado ativo. O dashboard mostra o último caso ativo; uma entrada com hash
banido recebe `machine_ban_hold` no ledger e a sessão é marcada como `banned`.

O que esse controle **não** é:

- não é atestação de GPU ou de hardware remoto;
- não é ban automático — o operador registra e pode reverter com `unban`;
- não é infalível: se o hash for calculado no PC do jogador, um cliente hostil
  pode enviar outro valor; trocar peças, reinstalar o sistema ou apagar o estado
  também muda o hash;
- não é identidade anônima: com o sal e os componentes, é possível testar
  candidatos. Trate o arquivo como dado pessoal pseudonimizado.

Em produção, defina `SENTINEL_HWID_SALT` com um valor próprio e mantenha o
arquivo fora do git, com acesso restrito e backup. Máquinas compartilhadas e
imagens clonadas podem gerar falso positivo; por isso o caso exige revisão e
apelação humanas.

## 5. O que “criptografia no código-fonte” significa aqui

Não existe configuração de compilador que torne um programa impossível de
copiar. O que foi feito, e pode ser auditado:

1. **Assinatura assimétrica**: sem a privada, não se emite chave válida.
2. **Verificação offline**: não há servidor de licença para derrubar nem tráfego
   de validação para interceptar.
3. **Fonte privado**: o repositório de código não é público; o pacote de
   avaliação contém apenas o executável e documentos.
4. **Build compilado**: PyInstaller empacota o bytecode; isso eleva o custo de
   cópia, não o torna infinito.
5. **Contrato**: EULA com escopo, proibição de redistribuição e rescisão.
6. **Marca e proveniência**: site, capa, logo e avisos de terceiros identificam
   a origem.

Se alguém copiar o binário e remover a verificação, estará violando a licença;
a Konaet não afirma que isso seja tecnicamente impossível. Qualquer promessa de
“100% à prova de cópia” seria falsa.

## 6. Evidência e integridade

Cada alerta grava `seq`, `prev`, `hash` e o conteúdo (features, risco, texto do
warden). `python -m sentinel verify` refaz a cadeia e aponta a primeira
divergência. Isso detecta edição no meio do arquivo. Apagar o arquivo inteiro ou
truncar o fim exige cópia externa (backup, WORM ou envio para outro host), que o
produto não substitui.

A evidência não contém endereço IP, e-mail ou dados de conta. Contém id do
jogador, nome de exibição, coordenadas e métricas. Trate o ledger como dado
pessoal e aplique retenção e acesso mínimo.

### Aprendizado local

A confirmação humana cria um registro `case` em `var/adaptation/cases.jsonl`,
com a mesma ideia de cadeia (`seq`, `prev`, `hash`) do ledger. A memória ativa
fica em `var/adaptation/memory.json` e carrega o SHA do modelo-base, o SHA das
âncoras e os protótipos. Na carga:

- hash divergente, modelo ou âncoras diferentes, protótipo que não pertence ao
  caso do journal ou estrutura inválida **rejeitam a memória inteira**; o motor
  segue com regras e modelo-base;
- journal adulterado impede a carga e faz `audit` falhar em `aprendizado`;
- rollback arquiva a memória e desliga o sinal no motor, sem apagar o journal.

Esses hashes detectam edição casual; **não são assinatura digital** contra quem
grava no disco e recalcula o hash. O journal contém id/nome do jogador, janelas
de features e o motivo escrito pelo operador: é dado pessoal local, não é
enviado à Konaet e deve seguir a mesma retenção do ledger. O modo demo usa
`var/adaptation/demo/`, separado da memória de produção.

## 7. Privacidade e rede

- Ingestão TCP e dashboard escutam em `127.0.0.1` por padrão.
- O POST `/api/ingest` pode exigir `X-Sentinel-Token` via
  `SENTINEL_INGEST_TOKEN`; o token nunca é gravado no ledger nem no dashboard.
- O dashboard não carrega CDN, fonte externa ou analytics. CSP restritiva e
  `X-Content-Type-Options: nosniff`.
- Nenhuma chamada externa é feita pelo serviço. O site de vendas é estático e
  só usa assets locais; a única saída é o link de WhatsApp clicado pelo usuário.
- A licença é verificada sem internet. O trial é local.
- O checkout coleta e-mail e comprovante apenas para emitir a chave; o PIX é
  estático, sem cobrança automática.
- O registro de banimento guarda hash de máquina, nome, motivo e operador. É
  dado pessoal pseudonimizado, fica em `var/` e não é publicado.
- O journal de aprendizado guarda janelas de comportamento, id/nome do jogador
  e o motivo da confirmação. Fica em `var/`, não é enviado à Konaet e deve ser
  tratado com a mesma retenção e acesso mínimo do ledger.

## 8. Operação segura

- Não rode a ingestão em `0.0.0.0` sem firewall; não exponha a porta à internet.
- Não publique `var/`, `license.key`, `trial.bin` ou a chave privada.
- Faça backup do ledger e da chave privada em locais separados.
- Em caso de vazamento da chave privada, gere um novo par, publique uma versão
  com a nova pública e reemita as licenças ativas; as antigas deixam de ser
  aceitas pelo cliente novo.
- Se uma cópia não autorizada for encontrada, registre hash, origem e captura
  antes de qualquer remoção. Não confunda correlação com autoria.

## 9. Como verificar

```bash
python -m unittest discover -s tests
python -m sentinel prove
python -m sentinel train
python -m sentinel bench
python -m sentinel machine
python -m sentinel bans
python -m sentinel verify var/evidence/demo.jsonl
python -m sentinel audit
python tools/adaptation_proof.py
```

Os testes cobrem assinatura, expiração, máquina, selo, banimento manual por
máquina e `machine_ban_hold`, CRC do PIX, o caminho completo de ingestão e a
memória de aprendizado (promoção, recusa de caso envenenado, adulteração,
protótipo fora do caso e rollback). O benchmark é sintético; leia o aviso no
relatório antes de citar os números.
`prove` roda 14 sessões sintéticas no motor real e só retorna `PASS` se todos os
gates passarem; ele é a prova rápida para quem não quer abrir o dashboard.

## 10. Binário não assinado e aviso do Windows

O executável do trial é gerado com PyInstaller e **não tem certificado
Authenticode**. SmartScreen, antivírus e reputação de download podem exibir
“O Windows protegeu seu PC” ou marcar um binário novo como suspeito. Isso é
diferente de uma detecção do motor e não prova que o arquivo é malicioso — mas
também não pode ser ignorado.

- A build 1.2 usa o modo **onedir** (pasta com `_internal/`), menos sujeito a
  heurística de autoextração do que o `--onefile` antigo.
- O pacote inclui `HASHES.txt` com SHA-256 de cada arquivo. O SHA-256 do ZIP é
  publicado no site e no repositório público.
- Verifique com `certutil -hashfile konaet-sentinel.exe SHA256` e compare.
- Se o hash não bater, apague e baixe de novo. Se bater, a decisão de executar
  é sua; nunca desative o antivírus inteiro.
- A única solução em escala para o aviso é assinatura de código com certificado
  confiável. O projeto não possui esse certificado e não promete instalação
  silenciosa.
- `prove` e o código-fonte (para licenciados) permitem verificar o comportamento
  sem depender da reputação do binário.
