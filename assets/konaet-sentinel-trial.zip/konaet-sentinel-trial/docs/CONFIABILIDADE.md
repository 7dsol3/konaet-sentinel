# Confiabilidade: o que foi medido e o que ainda não foi

Este documento existe para impedir uma mentira confortável. O Konaet Sentinel
tem um benchmark sintético, testes de perturbação e testes de perfil; isso prova
o pipeline e a resistência a degradações **simuladas**. Não prova detecção no
seu servidor, nem superioridade sobre VAC, EAC ou BattlEye. Onde a medição não
existe, o status é `NOT_RUN`.

Reproduza tudo com:

```bash
py -3.12 -m sentinel.train
py -3.12 -m sentinel.robustness
py -3.12 -m unittest discover -s tests
py -3.12 -m sentinel.cli prove
```

## 1. Benchmark sintético (holdout oficial)

O dataset é gerado pelo simulador determinístico incluído no pacote, no mesmo
protocolo de eventos do jogo. A divisão é por **sessão**, nunca por janela:
164 sessões de treino, 30 de validação e 30 de teste; 2.240 janelas e 482.562
eventos no total. O limiar é calibrado só na validação; o teste é lido uma vez.

| Métrica no teste | Valor | Gate |
|---|---:|---|
| Recall das regras em cheats overt | 1,000 | ≥ 0,90 |
| Recall híbrido em cheats stealth | 1,000 | ≥ 0,80 |
| Falso positivo por sessão legítima | 0,000 | ≤ 0,02 |
| AUC do modelo por janela | 0,9996 | ≥ 0,90 |
| Recall híbrido geral | 1,000 | ≥ 0,85 |

- Modelo: regressão logística, 17 sinais, artefato
  `fc4c3f7a80eb7261d966d8887ce43e8c685dee15cf6cc9b854738e9578cc9c88`.
- Limiar de alerta: 0,68; quarentena automática exige regra ≥ 0,86 ou duas
  janelas de modelo ≥ 0,92. O modelo sozinho não bane.
- O split de teste tem 14 sessões legítimas e 16 cheats. Zero falsos positivos
  em 14 é compatível, num intervalo de confiança aproximado de 95%, com um FPR
  real de até ~19% (regra de três). O número não deve ser lido como “FPR zero
  garantido”.
- O dataset é sintético e separável por construção. AUC 0,9996 aqui **não**
  significa AUC 0,9996 em tráfego real.

## 2. Robustez a perturbações (quatro seeds)

O teste pega o split de teste de cada seed (30 sessões: 14 legítimas, 16 cheats)
e aplica a mesma perturbação a todas as sessões. A tabela mostra o **pior caso**
entre as quatro seeds, não a melhor execução.

| Cenário | FPR máx. | Recall mín. | Stealth mín. | AUC mín. |
|---|---:|---:|---:|---:|
| baseline (sem perturbação) | 0,000 | 1,000 | 1,000 | 0,9995 |
| perda de 5% dos movimentos | 0,000 | 1,000 | 1,000 | 0,9996 |
| perda de 15% dos movimentos | 0,000 | 1,000 | 1,000 | 0,9988 |
| 5% de duplicatas | 0,000 | 1,000 | 1,000 | 0,9996 |
| ruído de posição σ=0,05 | 0,000 | 1,000 | 1,000 | 0,9995 |
| ruído de posição σ=0,15 | 0,000 | 1,000 | 1,000 | 0,9996 |
| atraso de rede de até 150 ms | 0,000 | 1,000 | 1,000 | 0,9992 |
| teleporte legítimo a cada 10 s | 0,000 | 1,000 | 1,000 | 0,9994 |
| stress (perda + ruído + atraso + teleporte) | 0,000 | 1,000 | 1,000 | 0,9996 |

Cada linha representa 120 avaliações de sessão (30 × 4 seeds), sendo 56
legítimas e 64 cheats. O relatório completo, com cada seed e cada cenário, está
em `artifacts/robustness.json` no repositório privado; o pacote de avaliação
leva uma cópia em `_internal/artifacts/robustness.json`.

O que mudou para chegar aqui, e por quê:

- velocidade e mira passaram a usar **deslocamento líquido** em 0,25–0,6 s, não
  diferença entre pacotes consecutivos; a regra usa a **mediana** dos pares,
  não o p90;
- atraso de rede pode encolher o intervalo entre dois pacotes em até ~0,15 s e
  inflar um par isolado; a mediana ignora a minoria distorcida, enquanto um
  cheat sustentado desloca todos os pares;
- teleporte do servidor recebe marcador e carência de ±0,6 s; movimento
  duplicado é descartado; a taxa de pacotes só conta o **excesso** sobre a
  taxa esperada do perfil (perda de pacotes não é suspeita);
- queda sem dano exige tempo de ar plausível e considera dano que chegou
  **antes** do pacote de pouso por reordenação; teleporte legítimo anula o
  registro;
- o mesmo limiar é usado em todos os cenários. Não há ajuste por cenário.

Ainda é síntese. As perturbações são limitadas ao que o simulador gera: perda
aleatória, duplicata, ruído gaussiano, atraso uniforme e teleporte. Não há
congestionamento em rajada, Jumbo frames, aceleração de tempo do servidor,
perda assimétrica por região, nem telemetria de um jogo real.

## 3. Perfis de jogo

Os oito perfis (`minecraft`, `dayz`, `infestation`, `pubg`, `cod`,
`battlefield`, `cs2`, `generic`) passam pela mesma matriz de testes:

- velocidade blatant (30 unidades/s) dispara a regra em todos;
- velocidade legal (70% do máximo do perfil) não dispara;
- alcance de braço só é avaliado onde o perfil habilita (`reach_p95`);
- alvos múltiplos usam a mesma regra em todos.

Isso prova a **semântica dos perfis** no simulador, não integração com os jogos.
O modelo de IA está calibrado apenas no perfil Minecraft; nos demais, rodam as
regras e o modelo fica desligado por calibração. Dizer que a IA “foi treinada
para todos os jogos” seria falso.

## 4. Escudo e `conceal_targets`

Os testes do escudo verificam os comandos gerados, a idempotência, os alvos
protegidos e que o jogador sinalizado nunca aparece na lista de alvos. O comando
`conceal_targets` é emitido só na quarentena e significa: **o adaptador do
servidor deixa de enviar a posição dos alvos protegidos ao cliente sinalizado**.
O servidor, o anti-cheat e os demais jogadores continuam vendo a posição real.
Não é invisibilidade no cliente, não altera o jogo do jogador limpo e não é
aplicável em servidor oficial de VAC, EAC ou BattlEye.

O efeito em partida real **não foi medido**: `NOT_RUN`. Testamos o contrato e a
lista de alvos; não existe servidor de jogo instrumentado neste repositório para
provar que o filtro de visibilidade reduz mortes. Um adaptador que não consiga
filtrar o que transmite a cada cliente deve ignorar o comando.

## 5. Auditoria local de integridade

O comando `audit` (e `audit --json`) confere, sem internet:

- o modelo carrega e o SHA-256 é `fc4c3f7a...`;
- o benchmark está em PASS, tem os cinco gates e aponta para o mesmo modelo;
- a robustez é versão 2, tem pelo menos duas seeds e dois cenários, todos
  `observed_clean`, e aponta para o mesmo modelo;
- os oito perfis esperados estão presentes;
- o ledger de evidência, quando existe, tem a cadeia SHA-256 íntegra;
- no executável congelado, o SHA do `.exe` confere com o `HASHES.txt` do pacote.

O relatório termina com o SHA-256 do próprio JSON canônico. Isso detecta
alteração posterior, mas **não é assinatura digital**: quem altera o relatório e
recalcula o hash produz outro hash válido. A verificação de origem continua
sendo o hash publicado e o `HASHES.txt` do pacote. A auditoria não prova
generalização para o seu servidor; ela prova que os artefatos são coerentes
entre si e com o pacote.

## 6. O que não foi testado

| Item | Status | Por quê |
|---|---|---|
| Telemetria rotulada de servidor real | `NOT_RUN` | Não há dataset de produção neste repositório |
| Comparação com VAC/EAC/BattlEye | `NOT_RUN` | Exigiria protocolo pareado e acesso aos dois lados |
| Integração oficial em PUBG, COD, Battlefield, DayZ oficial, Valve | `NOT_APPLICABLE` | O produto não injeta hooks em servidor de terceiros |
| Driver de kernel / attestation de GPU | `NOT_SHIPPED` | Fora do escopo; não é necessário para as regras atuais |
| Banimento automático | `NOT_SHIPPED` | Decisão humana por projeto |
| Detecção de cheat desconhecido | `NOT_PROVEN` | O modelo é supervisionado no que o simulador rotula |
| `conceal_targets` reduzindo dano em partida real | `NOT_RUN` | Depende do adaptador e do servidor do cliente |

## 7. Limite de honestidade

“Pegar todo cheat”, “nunca errar” ou “melhor que o VAC” não são afirmações
medidas e não devem ser publicadas. O que o produto entrega hoje é: regras
físicas explicáveis, modelo supervisionado com limiar calibrado, evidência
encadeada, escudo idempotente sem ban automático e um conjunto de testes
reproduzível. Para afirmar desempenho no seu jogo, colete telemetria rotulada
do **seu** servidor, rode o mesmo protocolo de treino/validação/teste e publique
os números — inclusive os ruins.
