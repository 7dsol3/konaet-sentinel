# Integração do Konaet Sentinel

O motor é agnóstico de jogo. A única parte específica da plataforma é o
**adaptador**: ele lê eventos autoritativos do servidor e escreve uma linha JSON
por evento no loopback. O mesmo motor que roda no modo demo processa a
telemetria real.

## 1. Topologia

```
servidor do jogo ──eventos──▶ adaptador ──JSONL/HTTP──▶ 127.0.0.1:47656
                                                         │
                                             motor + 17 sinais + modelo
                                                         │
                                       dashboard 127.0.0.1:8790
                                                         │
                                           comandos do escudo ──▶ adaptador
```

O adaptador e o serviço rodam **no servidor** — ou no processo confiável que o
operador controla. A proteção depende disso: a posição que vale é a que o
servidor calculou, e o comando de cancelar hits só tem efeito se o servidor
aplicá-lo.

## 2. Protocolo

- Transporte principal: TCP em `127.0.0.1:47656` (configurável em
  `--ingest-port`).
- Alternativa em lote: `POST http://127.0.0.1:8790/api/ingest` com corpo NDJSON
  (uma linha por evento, até 1 MiB por requisição).
- Uma linha por evento, UTF-8, no máximo 64 KiB.
- `t` é o instante de **recebimento no servidor**, em milissegundos de um relógio
  monotônico. Se o adaptador omitir, o serviço usa o horário de chegada. Nunca
  use o relógio enviado pelo cliente.
- Versão atual: `v: 1`.

Se `SENTINEL_INGEST_TOKEN` estiver definido, o POST exige o cabeçalho
`X-Sentinel-Token` com o mesmo valor. A porta TCP continua sendo loopback; para
expor além dele, use túnel autenticado e firewall.

### Eventos

| `type` | Campos obrigatórios | Opcionais relevantes |
|---|---|---|
| `hello` | — | `server`, `tps`, `players` |
| `join` | `player` | `name`, `game`, `machine` |
| `leave` | `player` | — |
| `move` | `player`, `x`, `y`, `z` | `yaw`, `pitch`, `on_ground`, `flying`, `sprinting`, `sneaking`, `in_water`, `on_ladder`, `vehicle`, `ping_ms` |
| `attack` | `player`, `target` | `distance`, `target_x`, `target_y`, `target_z` |
| `swing` | `player` | `target` |
| `break` | `player`, `x`, `y`, `z` | `block`, `min_ms`, `duration_ms`, `tool` |
| `place` | `player`, `x`, `y`, `z` | `distance`, `under_foot` |
| `damage` | `player` | `cause`, `amount` |
| `health` | `player` | `health` |
| `teleport` | `player`, `x`, `y`, `z` | — |

`player` é um identificador estável (UUID), não o nome exibido. Nomes são apenas
rótulos e são limitados a 64 caracteres, sem caracteres de controle.

### `join`: perfil e máquina

`game` escolhe o perfil físico daquela sessão e `machine` associa a impressão da
máquina. Ambos são opcionais e limitados a 32 e 80 caracteres,
respectivamente.

```json
{"v":1,"type":"join","player":"3f2b...","name":"Luan","game":"dayz","machine":"ks1-4f8f4c1d2a7b9e0c6d3a5f8b1c2e7a9d"}
```

Perfis embutidos: `minecraft` (referência, modelo calibrado), `dayz`,
`infestation`, `pubg`, `cod`, `battlefield`, `cs2` e `generic`. `csgo`,
`cs:go` e `counter-strike` são aliases de `cs2`; o perfil serve para servidor
comunitário/dedicado com telemetria autorizada, não para servidor oficial da
Valve. Sem `game`, vale o
perfil global de `--game` ou `SENTINEL_GAME`; sem nenhum dos dois, o padrão é
`minecraft`. Um nome desconhecido cai no padrão em vez de derrubar a sessão.

O perfil muda a semântica física — unidade, velocidade, alcance, regras de voo,
quebra e colocação. Ele **não** é uma integração oficial com o jogo. Para um
título novo, derive de um preset e ajuste as velocidades e o alcance:

```python
from sentinel import profiles

perfil = profiles.custom(
    "generic",
    key="meujogo",
    label="Meu Jogo",
    unit="metro",
    max_speed=7.0,
    reach_p95=None,   # shooters usam alcance de arma, não reach de braço
    reach_max=None,
    reach_instant=None,
    place_reach=None,
)
```

O modelo de IA só é usado quando `ml_calibrated` é verdadeiro. Nos demais
perfis, as regras rodam sozinhas até existir telemetria rotulada suficiente para
retreinar e recalibrar.

### Impressão de máquina

`machine` deve ser o hash `ks1-` seguido de 32 hexadecimais, gerado por
`sentinel.machine.fingerprint()` **no processo confiável** do operador
(servidor, launcher próprio ou agente instalado). O adaptador nunca envia o
identificador cru. O hash é salgado (defina `SENTINEL_HWID_SALT` em produção) e
serve como pseudônimo estável da instalação, não como atestação de hardware.

Limites explícitos: um cliente hostil pode falsificar o valor se o cálculo
estiver no PC do jogador; trocar componentes, reinstalar o sistema ou apagar o
estado muda o hash; máquinas compartilhadas podem gerar falso positivo. Por
isso o ban por máquina é **manual**, com motivo, evidência, operador e reversão.
Veja [SEGURANCA.md](SEGURANCA.md).

### Exemplo de movimento

```json
{"v":1,"type":"move","player":"3f2b...","x":128.5,"y":64.0,"z":-90.25,"yaw":90.0,"pitch":12.0,"on_ground":true,"sprinting":true,"t":482315}
```

### Adaptador de referência

[`sentinel/adapters/minecraft.py`](../sentinel/adapters/minecraft.py) traduz
chamadas de um plugin no formato de eventos do Minecraft. Não é um plugin
Bukkit/Paper: é a camada de tradução e o cliente TCP. Para jogos sem esse
formato, [`sentinel/adapters/generic.py`](../sentinel/adapters/generic.py)
oferece a base neutra.

```python
from sentinel.adapters.minecraft import MinecraftAdapter, Sender

adapter = MinecraftAdapter("Meu Servidor")
with Sender() as sender:
    sender.send(adapter.hello(tps=20.0, players=2))
    sender.send(adapter.join("uuid-1", "Luan"))
    sender.send(adapter.move("uuid-1", x=10.5, y=64.0, z=-3.0, on_ground=True))
```

Para o seu jogo, escreva a mesma tradução e mantenha as unidades:

- `move`: posição do jogador **depois** da validação de movimento do servidor;
- `attack`: atacante, alvo e distância calculada pelo servidor;
- `break`: `min_ms` é o tempo mínimo legal do bloco; `duration_ms`, o tempo real
  gasto. Quebra mais rápida que o mínimo é evidência;
- `place`: distância do jogador ao bloco e se o bloco está sob os pés;
- `teleport`: teleporte legítimo do servidor; não conta como violação.

O adaptador deve descartar eventos duplicados e não confiar em coordenadas que o
cliente enviou sem validação.

### Embutir no próprio processo

Quando o servidor é Python, não é preciso socket: `sentinel.embed.EmbeddedSentinel`
roda o mesmo motor no processo, sem abrir portas nem iniciar threads. O guia
completo, com exemplos para jogo, launcher, empresa e recusa de kernel, está em
[SDK.md](SDK.md).

```python
from sentinel.embed import EmbeddedSentinel

sentinel = EmbeddedSentinel(game="dayz", server="Meu Servidor",
                            ledger_path="var/evidence/meu-servidor.jsonl")
sentinel.join("uuid-1", "Luan")
sentinel.move("uuid-1", x=10.5, y=4.2, z=-3.0, on_ground=True)
for command in sentinel.commands():
    aplicar_no_servidor(command)
```

## 3. Escudo (agente protect)

O escudo não bane. Ele converte a escalada em comandos idempotentes:

| Ação | Efeito esperado no servidor |
|---|---|
| `clamp_movement` | rejeitar movimento que viole a física; manter o jogador na última posição válida |
| `cancel_hits` | cancelar dano do sinalizado contra os alvos listados |
| `limit_block_actions` | limitar quebra/colocação por tick e exigir tempo mínimo de quebra |
| `quarantine_combat` | remover o sinalizado da interação de combate; ele continua no mundo |
| `conceal_targets` | **filtro do servidor:** parar de enviar a posição dos alvos protegidos ao cliente sinalizado; o servidor e os demais jogadores continuam vendo a posição real |
| `request_review` | abrir um caso para revisão humana com o dossiê |

`conceal_targets` só existe quando **você controla o servidor**. Ele não é
invisibilidade no cliente, não altera o jogo do jogador limpo e não é aplicável
em servidores oficiais de VAC, EAC ou BattlEye. Se o seu adaptador não tiver como
filtrar o que transmite a cada cliente, ignore esse comando; os outros continuam
valendo. O anti-cheat segue registrando a posição verdadeira do alvo, e o
sinalizado pode ser revisado ou removido por um humano.

Os comandos ficam em `/api/protect` (leitura local) e no ledger como
`shield_action`, com o motivo e a evidência. O adaptador deve aplicá-los de forma
idempotente: repetir o comando não pode duplicar punição.

```python
from sentinel.adapters.minecraft import shield_commands

for command in shield_commands():
    apply_in_game(command["op"], command.get("player"), command.get("targets", []))
```

Regra de ouro: `cancel_hits` e `clamp_movement` são **mitigação temporária**,
não sentença. Quem decide banir é uma pessoa, olhando o dossiê.

Quando uma máquina com banimento ativo entra, o serviço marca a sessão como
`banned` e grava um evento `machine_ban_hold` no ledger. O adaptador deve
remover o jogador conforme a política do servidor; o produto não expulsa
ninguém sozinho.

## 4. Dashboard e API

O dashboard em `http://127.0.0.1:8790/` consulta:

- `GET /api/state` — jogadores, risco, features, evidência, feed e ledger;
- `GET /api/health` — versão, modo, hash do modelo e uptime;
- `GET /api/benchmark` — gates do último treino;
- `GET /api/network` — resumo do monitor de rede local (somente leitura);
- `GET /api/protect` — resumo do escudo, comandos recentes e banidos online;
- `GET /api/bans` — total, máquinas ativas, último caso e recentes;
- `GET /api/ledger/verify` — integridade da cadeia;
- `GET /api/config` — modo, servidor, perfil e URL da loja;
- `POST /api/ingest` — lote NDJSON (token opcional).

Tudo é leitura, exceto a ingestão. Não há endpoint para banir, expulsar ou
alterar jogador: o ban é um comando humano no servidor.

```bash
curl -s http://127.0.0.1:8790/api/bans
curl -X POST http://127.0.0.1:8790/api/ingest \
  -H "Content-Type: application/x-ndjson" \
  --data-binary @eventos.jsonl
```

A ingestão aceita conexões de `127.0.0.1` por padrão; `--host 0.0.0.0` existe
para casos explícitos e deve ser protegido por firewall ou túnel autenticado.
Não exponha a porta de ingestão à internet aberta.

### Monitor de rede local

O serviço inicia com um monitor somente leitura (`--no-netwatch` desliga,
`--net-interval` muda o período, padrão 3 s). Ele lê `netstat -ano -p TCP` e
`tasklist`, mostra conexões, escutas fora do loopback, processos e saída para
portas incomuns em `/api/network` e no painel **Rede**. Não bloqueia, não
encerra, não altera firewall e não envia dados para fora.

Para usar sem dashboard:

```bash
python -m sentinel.cli netwatch
python -m sentinel.cli netwatch --watch --interval 2
python -m sentinel.cli netwatch --json
```

Isso é visibilidade, não firewall/IDS/IPS. Serviços padrão do Windows (RPC,
NetBIOS, SMB) aparecem agrupados como informação de baixa severidade; RDP, VNC,
banco e Docker API merecem revisão. Leia [PANORAMA.md](PANORAMA.md#4-defender-a-rede-do-windows)
antes de vender isso como "proteção de rede".

## 5. Ordem de implantação

1. Rode `python -m sentinel demo` e confira o dashboard.
2. Escolha o perfil com `--game` e instrumente o adaptador em um servidor de
   teste, com um jogador e tráfego normal. O objetivo é zero alerta em sessão
   limpa.
3. Reproduza um cheat conhecido em ambiente controlado. Confirme que o alerta
   traz a feature esperada e que o comando do escudo é aplicado.
4. Colete telemetria rotulada do seu jogo e avalie o modelo com os seus dados.
   O benchmark incluído é sintético e não substitui essa etapa.
5. Ative o escudo em produção. Mantenha o ban manual e registre o motivo, a
   evidência e o operador.

## 6. Solução de problemas

- **Dashboard vazio**: confira `--http-port`, o modo (`demo` ou `live`) e se o
  adaptador está conectando em `127.0.0.1:47656`.
- **Eventos rejeitados**: o serviço conta linhas inválidas em `/api/state`
  (`bad_lines`). Valide `type`, `v:1` e os campos obrigatórios.
- **Modelo ausente**: o serviço roda somente com regras e mostra o aviso em
  `/api/config`. Rode `python -m sentinel train` para gerar os artefatos.
- **Escudo não aplica**: consulte `/api/protect`; comandos só são emitidos em
  escalada (`alert` ou `quarantine`), uma vez por jogador e nível.
- **Perfil errado**: confira `game` no `join` e o `profile` em `/api/config`.
  Perfis fora de Minecraft rodam sem IA até calibração.
- **Ban não aparece**: confira `var/bans.json`, o status ativo e se o `machine`
  enviado no `join` é exatamente o mesmo hash registrado.
