# Malha autoritativa de efeito

A partir da versão 1.4, o Konaet Sentinel pode decidir **o efeito de um disparo
antes de o dano ser aplicado**. O cliente propõe; o servidor decide. A decisão
usa a posição que o servidor aceitou, o alcance da arma, a linha de visão, a
mira, a cadência, o teto de dano e uma dispersão sorteada no servidor.

O objetivo é o jogador limpo que chegou primeiro, treinou a mira e aprendeu o
mapa: a regra do jogo continua valendo para ele mesmo quando outro cliente
injeta velocidade, teleporte, mira automática ou redução de recuo.

Isto **não** é invulnerabilidade, não é leitura de memória, não é driver de
kernel e não é detecção universal. É uma camada de arbitragem de efeito que só
existe quando o adaptador do servidor pergunta e aplica a resposta.

## O contrato

```
cliente do jogador ──tiro──▶ servidor do jogo
                                  │  posição/arma/LOS calculados pelo servidor
                                  ▼
                        POST /api/authority/shot
                                  │
                     ┌────────────┴────────────┐
                     ▼                         ▼
             alvo protegido              alvo não protegido
       aplica, limita ou nega       registra evidência e aplica
                     │                         │
                     └────────────┬────────────┘
                                  ▼
                     adaptador aplica o dano decidido
```

O adaptador precisa chamar a rota **de forma síncrona**, antes de causar o dano,
e usar `apply` e `damage` da resposta. Se o adaptador aplicar o dano original e
depois consultar a malha, a proteção não existe.

### Requisição

```http
POST http://127.0.0.1:8790/api/authority/shot
Content-Type: application/json

{
  "player": "uuid-do-atacante",
  "target": "uuid-do-alvo",
  "weapon": "rifle",
  "damage": 26,
  "distance": 30.0,
  "los": true,
  "x": 10.0, "y": 64.0, "z": -4.0,
  "target_x": 40.0, "target_y": 64.0, "target_z": -4.0
}
```

| Campo | Obrigatório | Semântica |
|---|---|---|
| `player` | sim | atacante; é a chave do estado autoritativo |
| `target` | sim | alvo do efeito |
| `weapon` | não | chave do catálogo do servidor; vazio usa a arma padrão do perfil |
| `damage` | não | dano declarado; ausente usa o dano da arma |
| `distance` | não | distância declarada; se houver origem e alvo conhecidos, o servidor recalcula |
| `los` | não | `true`/`false` conforme a linha de visão do servidor; ausente fica “não informado” |
| `x`,`y`,`z` | não | origem do disparo; os três juntos ou nenhum |
| `target_x`,`target_y`,`target_z` | não | ponto do alvo; os três juntos ou nenhum |

Os campos `x/y/z` são comparados com a última posição **aceita** pelo servidor
para aquele jogador, não com o que o cliente alegou. A tolerância horizontal é
2,5 m. O alvo também precisa ter posição aceita para a checagem de mira; sem
isso, a mira não é verificável e a decisão não inventa uma violação.

### Resposta

```json
{
  "ok": true,
  "apply": false,
  "enforced": true,
  "denied": true,
  "player": "uuid-do-atacante",
  "target": "uuid-do-alvo",
  "weapon": "rifle",
  "scope": "protected",
  "damage": 0.0,
  "declared_damage": 26.0,
  "server_distance": 30.0,
  "suspect": true,
  "reasons": ["line_of_sight"],
  "reason_labels": ["sem linha de visão do servidor"],
  "checks": {"distance_m": 30.0, "los": false},
  "latency_us": 18.2
}
```

- `apply=false` e `damage=0`: o adaptador não aplica dano.
- `apply=true` e `damage=...`: o adaptador aplica exatamente esse valor; ele pode
  ser menor que o declarado por teto de arma.
- `scope="evidence"`: o alvo não está protegido; a malha registra violações, mas
  **não altera** o efeito. A decisão normal do servidor continua valendo.
- `denied=true` só existe quando `scope="protected"` e o efeito foi negado.

## O que cada checagem faz

| Checagem | Regra | Efeito contra protegido |
|---|---|---|
| Origem | distância horizontal entre a origem declarada e a última posição aceita > 2,5 m | nega |
| Movimento | deslocamento acima de `max_speed × dt × 1,35 + 1,0 m` | nega o movimento; o adaptador mantém a última posição aceita |
| Alcance | distância do servidor acima de `range × 1,03 + 0,35 m` | nega |
| Linha de visão | `los=false` informado pelo servidor | nega |
| Mira | ângulo entre a direção da câmera e o alvo > raio angular + 10° | nega |
| Cadência | intervalo entre disparos aceitos abaixo de `interval × 0,85` | nega |
| Dano | dano declarado acima de `arma.damage × 1,02` | nega; acima do teto vira o teto |
| Dispersão | sorteio SHA-256 com segredo do servidor, somente contra protegido e somente se o atacante é suspeito ou já violou uma regra dura | pode negar (miss do servidor) |

O catálogo padrão é:

| Arma | Alcance | Intervalo | Dano | Dispersão | Hitbox |
|---|---:|---:|---:|---:|---:|
| `melee` | 4,8 m | 0,45 s | 7 | 4,0° | 0,55 m |
| `rifle` | 45 m | 0,12 s | 26 | 1,2° | 0,32 m |
| `smg` | 32 m | 0,075 s | 18 | 2,2° | 0,32 m |
| `dmr` | 120 m | 0,45 s | 55 | 0,7° | 0,32 m |
| `sniper` | 300 m | 1,2 s | 90 | 0,35° | 0,32 m |

Perfis de sandbox usam corpo a corpo com o alcance do perfil; shooters usam
fuzil. O adaptador pode declarar outra arma, mas uma chave fora do catálogo é
`weapon_unknown` e, contra protegido, nega — falha fechada.

A probabilidade de acerto da dispersão é uma aproximação de disco uniforme:

```
p = (atan(hitbox / distância) / radians(dispersão))²
```

Ela é recalculada pelo servidor, não aceita do cliente. O sorteio é determinístico
para o mesmo segredo, sequência, atacante, alvo e instante; o segredo é gerado no
processo e não sai na API. Reiniciar o serviço muda o segredo e, portanto, a
sequência de sorteios — o que é intencional e não afeta a legitimidade dos tiros
limpos.

## Quem é “protegido”

A lista é explícita:

```bash
python -m sentinel serve --game cs2 --protect "uuid-1,uuid-2"
python -m sentinel serve --game cs2 --protect "uuid-1" --protect "uuid-2"
SENTINEL_PROTECT="uuid-1,uuid-2" python -m sentinel serve --game cs2
```

No modo demo, `legit-0` é protegido automaticamente para o painel mostrar a
malha sem fingir combate entre jogadores reais. Em produção, **nenhum jogador é
protegido por padrão**; a proteção é uma decisão operacional do servidor.

Também é possível ligar e desligar em execução:

```http
POST /api/authority/protect
X-Sentinel-Action: protect
Content-Type: application/json

{"player": "uuid-1", "protected": true}
```

A rota exige o cabeçalho de ação, respeita `Origin` e, se o serviço estiver
exposto fora do loopback, exige `SENTINEL_ADMIN_TOKEN`. A mudança vai para o
ledger como `authority_protect`.

## O que a malha não faz

- **Não torna o protegido invulnerável.** Um inimigo limpo, com posição, mira,
  alcance e LOS válidos, continua aplicando 100% do dano. O artefato mede
  208 → 208 nos cenários `legit_enemy` e `clean_duel`.
- **Não nerfa o protegido.** O dano de saída dele contra outros alvos continua
  integral; o cenário `protected_output` mede 208 → 208.
- **Não pune conta.** Não há ban automático. A malha nega ou limita efeito,
  registra o motivo e alimenta o escudo e o dossiê; a decisão de banir segue
  humana.
- **Não lê memória, não injeta no cliente, não usa driver de kernel.** Um cheat
  que produz entradas fisicamente válidas — mira humanizada, recuo compensado
  dentro do intervalo, posição dentro da velocidade — não é distinguido por
  geometria. Esse caso é assunto da camada comportamental (regras + IA +
  memória confirmada), com os limites dela.
- **Não funciona sem o adaptador.** Sem uma chamada síncrona no servidor, a
  malha não vê o tiro e não altera nada. Não há integração oficial com VAC, EAC,
  BattlEye, PUBG, COD, Battlefield ou servidores oficiais da Valve.
- **Não compensa latência de rede.** O tempo de decisão é local (dezenas de
  microssegundos nesta máquina), mas a latência entre cliente e servidor não é
  modelada por esta camada.
- **Não substitui a validação no seu servidor.** A prova incluída é sintética e
  determinística; validação em servidor real está declarada como `NOT_RUN`.

## Falha e degradação

A malha é uma camada adicional, não um requisito de disponibilidade do jogo. Se
a rota estiver fora do ar, lenta ou devolver erro, o adaptador deve aplicar a
regra normal do servidor e registrar a falha. **Timeout não é “negado”**: tratar
indisponibilidade como negação transformaria o protegido em invulnerável e
premiaria quem derrubasse o serviço.

Contra um alvo protegido, porém, a recomendação é **falha fechada para efeitos
que o próprio servidor já considera impossíveis** (alcance, LOS, origem, dano
acima do teto) e **falha aberta para o que a malha não conseguiu verificar**
(mira sem posição de alvo, LOS não informado). O adaptador deve distinguir
“negado pela política” de “não foi possível decidir”.

## API e auditoria

| Rota | Efeito |
|---|---|
| `POST /api/authority/shot` | decisão síncrona de um efeito; token de ingestão quando configurado |
| `GET /api/authority` | resumo, protegidos, suspeitos, dano negado, latências, decisões recentes e prova |
| `POST /api/authority/protect` | liga/desliga proteção; exige `X-Sentinel-Action: protect` |

O ledger registra:

- `authority_move` — movimento recusado, com delta e orçamento;
- `authority_void` — efeito negado contra protegido, com motivos e dano declarado;
- `authority_protect` — mudança na lista de protegidos.

O comando `python -m sentinel audit` inclui a verificação `malha`, que confere o
artefato, o número de gates, a versão da política e o SHA-256 da política. Um
artefato adulterado faz a auditoria falhar.

## Prova reproduzível

```bash
python tools/authority_proof.py
```

O relatório `artifacts/authority.json` usa o perfil `cs2`, fuzil, segredo fixo de
prova (`konaet-authority-proof-v1`) e semente `20261029`. São 11 cenários e 110
disparos sintéticos, incluindo ataques construídos e duelos limpos.

Resultado da build 1.4.0 nesta máquina:

| Medida | Resultado |
|---|---|
| Dano de trapaça antes → depois | 2.996 → 416 (13,9% retido) |
| Speedhack, teleporte, wallbang, alcance, dano ampliado, combinado | 0 de dano aplicado |
| Cadência | 15/20 disparos negados |
| Recuo macro (`no_recoil`) | 27,5% de acerto vs 25,9% de probabilidade do servidor a 30 m |
| Inimigo limpo contra protegido | 208 → 208 (100%) |
| Saída do protegido | 208 → 208 (100%) |
| Negações indevidas em 24 tiros limpos | 0 |
| Latência por decisão | p50 16,5 µs · p95 32,8 µs · máx. 116,7 µs |
| Política | v1 · SHA-256 `1da64c4ad04d7abec87d1b5c704f41da7021d56aee8434dece07067ce6de746d` |

Os dez gates do artefato são: `impossible_zero`, `damage_cap`, `cadence`,
`server_spread`, `no_pay_to_win`, `clean_output`, `no_false_voids`, `latency`,
`deterministic` e `policy`. O comando `prove` também roda um probe curto da malha
e falha se o contrato básico quebrar.

O que esses números significam: **neste conjunto sintético**, os ataques
construídos perdem quase todo o dano contra o alvo protegido, enquanto tiros
limpos mantêm o dano. O que eles não significam: superioridade sobre qualquer
anti-cheat, cobertura de todos os cheats, ou prova de que o seu servidor está
protegido. Para o seu jogo, o caminho é adaptador + telemetria rotulada +
validação no seu ambiente.

## Integração no adaptador, em pseudocódigo

```python
def aplicar_dano(atacante, alvo, arma, dano, origem, ponto_alvo, los):
    decisao = sentinela.post("/api/authority/shot", {
        "player": atacante.id,
        "target": alvo.id,
        "weapon": arma.chave,
        "damage": dano,
        "los": los,
        "x": origem.x, "y": origem.y, "z": origem.z,
        "target_x": ponto_alvo.x, "target_y": ponto_alvo.y, "target_z": ponto_alvo.z,
    }, timeout=0.05)

    if decisao is None:
        # malha indisponível: aplica a regra normal do servidor e registra
        return dano_normal_do_servidor()

    if not decisao["apply"]:
        ledger.registrar("efeito_negado", decisao["reasons"])
        return 0.0

    return decisao["damage"]
```

Regras de ouro:

1. A posição vem do servidor, nunca do cliente.
2. `t` da malha é o relógio de recebimento no Sentinela, não o timestamp do
   pacote do jogador.
3. O adaptador aplica `apply`/`damage`; não reinterpreta os motivos.
4. Movimento recusado mantém a última posição aceita; teleporte legítimo usa
   `accept_teleport` (evento `teleport` na ingestão).
5. Não envie o tiro duas vezes (uma para telemetria e outra para a malha) sem
   idempotência; a malha conta cada chamada como um disparo.

## Limites declarados

- Sem prova em servidor real: `NOT_RUN`.
- Sem comparação com VAC, EAC, BattlEye ou qualquer anti-cheat de terceiros.
- Sem garantia contra cheats que produzem entradas fisicamente válidas.
- Sem proteção sem adaptador, sem posição autoritativa e sem LOS/mira quando o
  servidor não os calcula.
- Sem ban automático, sem expulsão e sem punição de conta pela malha.
- A lista de protegidos é operacional; não é um plano comercial de vantagem
  dentro do jogo.

Se você precisa de uma garantia maior, o caminho é mover mais semântica para o
servidor — posição, LOS, dano e cadência — e validar com telemetria do seu jogo.
A malha entrega o mecanismo e a prova do mecanismo; não vende a ilusão de que
qualquer cliente hostil se torna inofensivo em qualquer jogo.
